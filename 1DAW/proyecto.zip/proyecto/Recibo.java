//sara

public class Recibo extends Economia{
    private int cod;
    
    
    public Recibo(){
        cod=0;

    }
    public Recibo(int cod, int mes, double dinero){
        super(mes,dinero);
        this.cod=cod;

    }

    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    @Override
    public String toString(){
        return "Código "+cod+" mes "+mes+" dinero "+dinero;
    }
}
