//sara

public class Economia {
    protected int mes;
    protected String desc;
    protected double dinero;
    protected String estado;

    public Economia(){
        mes=0;
        desc=" ";
        dinero=0.0;
        estado=" ";
    }
  
  
    public Economia(int mes, double dinero){
        this.mes=mes;
        this.dinero=dinero;
    }


    public Economia( int mes, String desc, double dinero, String estado){
        this.mes=mes;
        this.desc=desc;
        this.dinero=dinero;
        this.estado=estado;
    }
}
