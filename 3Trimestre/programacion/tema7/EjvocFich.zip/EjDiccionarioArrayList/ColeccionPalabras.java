package EjDiccionarioArrayList;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class ColeccionPalabras {
    
    private ArrayList<Palabra> palabras;
    private boolean modif = false;

    public ColeccionPalabras() {

        palabras = new ArrayList <Palabra>();
    }

    public int busquedaDesordenado (String palabraBus, String idioma) {

        int i = 0, pos = -1;

        while (i < palabras.size() && pos == -1) {
        
            if ((idioma.equals("espanyol") && palabraBus.equals(palabras.get(i).getEspanyol())) || (idioma.equals("ingles") && palabraBus.equals(palabras.get(i).getIngles())) || (idioma.equals("frances") && palabraBus.equals(palabras.get(i).getFrances()))) {
                pos = i;
            } else {
                i ++;
            }
        }
        return pos;
    }

    public void borrar (String palabra, String idioma) {
 
        int pos = busquedaDesordenado(palabra, idioma);

        palabras.get(pos).setEspanyol("");
        modif = true;
    }

    public ArrayList<Palabra> getPalabras() {

        return palabras;
    }

    public void add(Palabra p) {

        palabras.add(p);
        modif = true;
    }

    public void mostrar() {

        for(int i = 0; i < palabras.size(); i++) {
            System.out.println(palabras.get(i).toString());
            System.out.println("------------------------------------------------");
        }
    }

    public void CargarFichero(ColeccionPalabras colec,String nomfich){
        try(BufferedReader br = new BufferedReader(new FileReader(nomfich))){
            String linea;
            while ((linea = br.readLine()) != null) { 
                String[] cort = linea.split(",");
                if (cort.length == 3) {
                    String esp = cort[0].trim();
                    String ing = cort[1].trim();
                    String fra = cort[2].trim();
                    Palabra pal = new Palabra(esp,ing,fra);
                    colec.add(pal);
                }
            }
            System.out.println("Palabra añadida correctamente");
        } catch (Exception e) {
        }
    }    

    public void MostrarMenu(String nomfich){
        try (BufferedReader br = new BufferedReader(new FileReader(nomfich))){
            String linea;
            System.out.println("El fichero tiene dentro estas palabras: ");
            while ((linea = br.readLine()) != null) {
            System.out.println(linea);
            }
        } catch (Exception e) {
        }
    }

    public void InsPalFich(String nomfich){
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(nomfich))) {
            
            if (modif == true) {
                for (Palabra p : palabras) {
                    bw.write(p.getEspanyol() + "," + p.getIngles() + "," + p.getFrances());
                    bw.newLine();
                }
                System.out.println("Colección actualizada en el fichero.");
                
            }else
            System.out.println("No han habido modificaciones");
        } catch (IOException e) {
            System.out.println("Error al guardar el fichero: " + e.getMessage());
        }

    }

}
